typedef Output = int;

bool isSuccessful({
  required Output actual,
  required Output target
}) {
  return actual >= target;
}