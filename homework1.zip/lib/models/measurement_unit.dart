enum MeasurementUnit {
  seconds,
  repetitions,
  meters
}